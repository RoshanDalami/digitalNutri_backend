import express from 'express'
// import {Promo} from '../controllers/promo.controller.js'
const PromoRouter = express.Router();

// PromoRouter.post('/promoCode',Promo)
export default PromoRouter